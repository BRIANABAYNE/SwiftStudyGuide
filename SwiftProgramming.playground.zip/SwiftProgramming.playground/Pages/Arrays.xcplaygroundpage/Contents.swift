//: [Previous](@previous)
/// Array - Insert, Append, Remove,
import Foundation
/// Mutable
var array = ["briana","Dad","Rosie","Maureen"]
array.append("Gigi")
print(array)


var fruitArray = ["Apple","banana","Orange","Grapes","Cherries"]
fruitArray.append("Kiwi")
fruitArray += ["Elderberry"] // another way to add without using "append"
print(fruitArray)

var exboyfriends = ["Robbie Richards","Chris bullock","Travis Durffee","Revise Jordan", "Joe"]
//exboyfriends.insert("Matty Temple", at: 3)

for boyfriend in exboyfriends {
    print(boyfriend)
}

for (index, boyfriend) in exboyfriends.enumerated() {
    print("boyfriend\(index + 1): \(boyfriend)")
}

exboyfriends.remove(at: 4)
print(exboyfriends)


exboyfriends.forEach { boyfriend in
    print(boyfriend)
}




/// Immutable
let newJob = ["iOS Dev", "$133,000", "Roth Match", "Fitness Allowance $300", "Paid Health Insurance"]

///Iterating through each element in an array - for loop
let colors = ["Pink","Green","Orange","Green"]

for color in colors {
    print(color)
}

/// Using Enumerated Method - If you need to know the index of each element while iterating, you can use Enumerated method

for (index, color) in colors.enumerated() {
    print("Color \(index + 1): \(color)")
}

/// For  Each - Is a method as an alternative to the for in loop, forEach method takes a closure, which is kind of a function and applies it to each element in the array
colors.forEach { color in
    print(color)
}


/// Count - Returns the number of elements in the array
let brianIsSoSmart = ["and Pretty","Strong","Healthy"]
print(brianIsSoSmart.count)

/// IsEmpty
print(brianIsSoSmart.isEmpty)

/// First and Last Property of an Array - will return an optional
print(brianIsSoSmart.first)
// LAST
print(brianIsSoSmart.last)

/// Max and Min - Method returns the max and min elements in the array - Great for array with numbers - returns an optional
let numbers = [-1,1,2,3,4,5]
print(numbers.max())
print(numbers.min())

/// Checking to see if 2 arrays have the same element

let coffee1 = ["latte","chai","blacktea"]
let coffee2 = ["latte","chai","blacktea"]
print(coffee1.elementsEqual(coffee2))

let dataTypes = ["String","Int","bool"]
let dataTypes1 = ["String","Int"]
print(dataTypes.elementsEqual(dataTypes1))


/// Method can compare arrays of different types, as long as the elements can be compared. EXAMPLE - you can compare an array of integers with an array of doubles
let intArray = [1,2,3,4,5]
let doubleArray = [1.0,2.0,3.0,4.0,5.0]
print(intArray.elementsEqual(doubleArray, by: {(a,b) in a == Int(b) }))


/// Filter - Requires a closure that takes an element from the array and returns a boolean value. - If returns true for an element, the element is included in the filtered array,
/// If the closure returns 'false' the element is excluded
let numbersArray = [1,2,3,4,5,6]
let evenNumbers = numbersArray.filter { $0 % 2 == 0 }
    print(evenNumbers)


let numbersArray1 = [1,2,3,4,5,7,10,33,24]
let oddNumbers = numbersArray1.filter { $0 % 1 == 0 }
print(oddNumbers)


/// $0 Means first argument in a closure - is also has .hasPrefix attached to it. $0 is placeholder for each element in the array
let names = ["Rosie","Robin","bob","Clair","George"]
let rNames = names.filter { $0.hasPrefix("R") }
print(rNames)

let animals = ["Cat","Colos","Dog","Fish","Monkey",]
let cNames = animals.filter { $0.hasPrefix("C")}
print(cNames)

/// Multidimensional and Nested Arrays
/// This code is matrix is an array of arrays integers.  It has three elements, each of which is an array of three integers 
var matrix: [[Int]] = [[1,2,3,4],[5,6,7],[8,9,10]]
//: [Next](@next)
