//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"
/// Allows to save all bits of data, for security - username, passwords, saves in tables - key value pair?? I believe
//: [Next](@next)
