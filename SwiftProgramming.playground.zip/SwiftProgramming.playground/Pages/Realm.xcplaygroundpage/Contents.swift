//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"
/// Faster and easier database solution
//: [Next](@next)
