/*:
 # Class , Struct, Enum
 Definition of *Class* - Reference type, using a class will **increase** the reference count when passed to a function or assigned to a var or let.
 
 **Why Class?** - If you need to reference that same instance of that class everywhere in your app.
 
 Definition of *Struct* - Value type, When a struct is assigned to a var or let, or passed into a function, that value type is **copied**, this *doesn't'* increase the reference count.
 
 Definition of *Enum* - A way to define a type that can only have a certain set of values.
*/
//: [Next](@next)
import Foundation

class BrianaBayne {
    let name: String
    var age: Int
    let single: Bool
    let weight: Int

    init(name: String, age: Int, single: Bool, weight: Int) {
        self.name = name
        self.age = age
        self.single = single
        self.weight = weight
    }
}

struct BabyBWeightLifting {
    var backSquat: Int
    var clean: Double
    var snatch: Int
}

enum Seasons: String {
    case summer
    case winter
    case fall
    case spring
}

