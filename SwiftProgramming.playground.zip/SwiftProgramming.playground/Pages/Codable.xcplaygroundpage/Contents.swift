//: [Previous](@previous)

import Foundation
/// Flash freezing custom objects - into a plist
/// You have to load the whole plist into memory to gain access to the objects - memory intensive - SMALL amounts of data less than 100 Kilobytes
//: [Next](@next)
