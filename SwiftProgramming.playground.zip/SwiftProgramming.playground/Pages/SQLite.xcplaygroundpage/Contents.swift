//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"
/// Persist large amounts of data and query it
/// Light weight, easy to use, large amounts of data / quick and easier on memory 
/// Query 
//: [Next](@next)
