//: [Previous](@previous)

import Foundation

/// Example :
/// value = condition ? value if true  : value if false

//: [Next](@next)
