//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"
/// Object -oriented database - data base - used with larger amount of data
/// coreData allows to create, read, update, delete 
/// Entity = Class - each Entity is like a table
/// Attributes = Properties
/// Codegen - 3 options
/// option 1: Class Definition - converts your data into class and properties
/// option 2: Pick Category/ Extension if you want to add custom init or extensions onto your model - if you want to add extra code
/// optional 3: Manual - have to do everything on your own
/// Defining OOP Word, Core Data World, Database World
///
/// OOP World            core data world                   Database World
/// class                      Entity                                     Table
/// property                 Attribute                                  Field
///

/// When we are dealing with coreData we put all of the entities into a container - that becomes the persistence container and that container is SQLite,  When I want to create data, read data, update data and delete data, we can't go through the persistence store directly so we have to go through a context. This context plays as the middle man, it's a temporary area where you might create new pieces of data such as the CRUD functions. The middle man is where you do the changes and then when you are happy, you call the try context.save and then it's updated to the persistence container. 
//: [Next](@next)
