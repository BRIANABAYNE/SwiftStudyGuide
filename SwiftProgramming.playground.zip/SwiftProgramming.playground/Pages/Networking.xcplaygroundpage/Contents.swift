//: [Previous](@previous)
/// URLSession.shared is a singleton
import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
