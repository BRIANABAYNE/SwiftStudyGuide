//: [Previous](@previous)

import Foundation

/// Sandboxing - Each app has their own sandbox - this sandbox helps protect the data on the phone - each app has folders that saves the information of the app - can't get access to
/// another document folder - can read and write to the data - if you get a new phone, the folder will still be available - iphone are considered to be much safer than other

//: [Next](@next)
