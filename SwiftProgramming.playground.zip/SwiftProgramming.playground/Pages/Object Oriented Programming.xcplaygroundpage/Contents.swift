import Foundation

/*:
 # Object Oriented Programmings
 Definition of *Oriented Programmings* - Identification of classes of objects linked with methods (functions) with which they are associated.
 Definition of *Class* - Example - Instrument is the instrument hierarch, blueprint which forms the basis of any kind of instrument.
 Definition of *Properties* - Declare the stored properties for the class instrument, these store properties have data types
 Definition of *Initialize* - Init the class with all the stored properties, this is creating or initializing the data types/ properties for that class.
 */
//: [Next](@next)


class Instrument  {
    let piano: String
    let guitar: String
    let drums: String

    init(piano: String, guitar: String, drums: String) {
        self.piano = piano
        self.guitar = guitar
        self.drums = drums
    }
}
