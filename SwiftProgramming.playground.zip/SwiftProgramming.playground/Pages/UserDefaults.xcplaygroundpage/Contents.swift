//: [Previous](@previous)
/// UserDefaults should only be used to store small amounts of data - persist
/// When you save array or dictionaries, it can become troublesome because userDefaults is not a database.
/// Store data in the user's  plist file - has to be loaded up - can time consuming for user experience - speed of the app
/// Stores preferences that persist across launches of the app
/// key value pairs 
/// USERDefaults are a singleton - only one copy that can be shared

/// code
import Foundation


/// Inside of the userDefaults there is a singleton named "standard" that is always pointing to the same plist, where all the data is persisting to. 
let userDefault = UserDefaults.standard

let myArray = "myArray"
let dictionaryKey = "myDictionary"
/// Saving User preferences inside of the app -
/// Example:  a volume of a game, you could save that value inside of UserDefaults and it would always be that volume when the user comes back to the game.
userDefault.set(0.24, forKey("Volume"))
userDefault.set(true, forKey("MusicOn"))
userDefault.set("briana", forKey("Bayne"))
/// Array
let array = [1,2,3,4]
userDefault.set(array, forKey("Myarray"))
/// Dictionary
let dictionary = ["briana": "bayne"]
userDefault.dictionary(forKey: dictionaryKey )




let volume = userDefault.double(forKey: "Volume")
let myArray = userDefault.array(forKey: myArray) as! [Int]
let dictionary = userDefault.dictionary(forKey: "MyDictionary")
