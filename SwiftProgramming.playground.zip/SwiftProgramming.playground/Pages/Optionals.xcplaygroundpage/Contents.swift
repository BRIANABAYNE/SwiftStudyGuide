//: [Previous](@previous)

import Foundation

/*:
 # Optionals - A enum with two cases - value or nil, use a ? - Must unwrap all optional values before you can use them.
 Definition of *Optional binding * - if let or guard let to a variable
 Definition of * Optional chaining* - To safely access the properties and methods of a wrapped instance, use the postfix optional chaining operator(postfix?)
 Definition of * Nil Coalescing * - Gives a default value if there is no value - ??
 Definition of * Unconditional Unwrapping * - When certain that an instance of optional contains a value, force unwrap with a bang
 Definition of * *
 */

//: [Next](@next)

/// Optional
