/*:
 # Communication Patterns
 Definition of *Protocol* - Defines a blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality.
 
 What can adopt **protocols?** - class, struct, enums, extensions.
 
 Definition of *Delegate* - Design pattern that enables a class to delegate some of it's responsibilities to an instance of that class.
 Will delegate a task to get done. One to One communication with *protocols*
 
 Definition of *Single Source of Truth* - A class that returns only one and the same instance no matter how many times you request it. Creates a global state.
 
 *Singleton Overuse* - Makes debugging and working with code difficult.
 
 Definition of *Observer Design Pattern* - Allows an object to notify other objects called *Observer* to any changes to it's state, one to many.
 
 Definition of *NotificationCenter* 
 */
//: [Next](@next)
